package spiderman;
import java.util.*;

public class Anomaly {
    public Person anomaly;
    public ArrayList<Integer> path;
    public int allotedTime;
    public boolean suc = true;
}
