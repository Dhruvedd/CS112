package spiderman;
public class Person {
    public int currDim;
    public String Name;
    public int belong;
    public boolean spider;
}
