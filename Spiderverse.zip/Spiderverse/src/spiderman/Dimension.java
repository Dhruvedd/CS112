package spiderman;

public class Dimension {

    public int DimensionNum;
    public int CanonNum;
    public int weight;





    public int getDimensionNum(){
        return DimensionNum;
    }

    public void setDimensionNum(int newNum){
        this.DimensionNum = newNum;
    }

    public int getCanonNum(){
        return CanonNum;
    }

    public void setCanonNum(int newNum){
        this.CanonNum = newNum;
    }

    public int getWeight(){
        return weight;
    }

    public void setWeight(int newWeight){
        this.weight = newWeight;
    }

    
}
